import numpy as np
from numpy.random import seed
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import pandas as pd

class LogisticRegressionSGD(object):
    """Logistic Regression classifier using Stochastic Gradient Descent.

    Parameters
    ------------
    eta : float     Learning rate (between 0.0 and 1.0)
    n_iter : int    Passes over the training dataset.
    shuffle : bool (default: True)
        Shuffles training data every epoch if True to prevent cycles.
    random_state : int (default: None)
        Set random state for shuffling and initializing the weights.

    Attributes
    -----------
    w_ : 1d-array   Weights after fitting.
    cost_ : list    Log-loss cost function value averaged over all
                    training samples in each epoch.
    """

    def __init__(self, eta=0.01, n_iter=10, shuffle=True, random_state=None):
        self.eta = eta
        self.n_iter = n_iter
        self.w_initialized = False
        self.shuffle = shuffle
        if random_state:
            seed(random_state)

    def sigmoid(self, z):
        """Compute sigmoid activation"""
        # Clip z to avoid overflow
        z = np.clip(z, -250, 250)
        return 1.0 / (1.0 + np.exp(-z))

    def fit(self, X, y):
        """Fit training data.

        Parameters
        ----------
        X : {array-like}, shape = [n_samples, n_features]
            Training vectors
        y : array-like, shape = [n_samples]
            Target values

        Returns
        -------
        self : object
        """
        self._initialize_weights(X.shape[1])
        self.cost_ = []

        for i in range(self.n_iter):
            if self.shuffle:
                X, y = self._shuffle(X, y)
            cost = []
            for xi, target in zip(X, y):
                cost.append(self._update_weights(xi, target))
            
            avg_cost = np.mean(cost)
            self.cost_.append(avg_cost)
        return self

    def partial_fit(self, X, y):
        """Fit training data without reinitializing the weights"""
        if not self.w_initialized:
            self._initialize_weights(X.shape[1])
        if y.ravel().shape[0] > 1:
            for xi, target in zip(X, y):
                self._update_weights(xi, target)
        else:
            self._update_weights(X, y)
        return self

    def _shuffle(self, X, y):
        """Shuffle training data"""
        r = np.random.permutation(len(y))
        return X[r], y[r]

    def _initialize_weights(self, m):
        """Initialize weights to small random numbers"""
        self.w_ = np.random.normal(loc=0.0, scale=0.01, size=1 + m)
        self.w_initialized = True

    def _update_weights(self, xi, target):
        """Apply logistic regression learning rule to update the weights"""
        output = self.sigmoid(self.net_input(xi))
        error = target - output
        
        # Update weights
        self.w_[1:] += self.eta * xi * error
        self.w_[0] += self.eta * error
        
        # Return log-loss
        cost = -target * np.log(output + 1e-15) - (1 - target) * np.log(1 - output + 1e-15)
        return cost

    def net_input(self, X):
        """Calculate net input"""
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def predict_proba(self, X):
        """Return probability estimates"""
        return self.sigmoid(self.net_input(X))

    def predict(self, X):
        """Return class labels"""
        return np.where(self.predict_proba(X) >= 0.5, 1, 0)

    def plot_sigmoid_prediction(self, X, y, sample_idx=None):
        """Plot sigmoid curve and predictions for selected samples"""
        plt.figure(figsize=(10, 6))
        
        # Generate points for sigmoid curve
        z = np.linspace(-10, 10, 1000)
        s = self.sigmoid(z)
        plt.plot(z, s, 'b-', label='Sigmoid curve')
        
        # Plot actual predictions
        if sample_idx is None:
            sample_idx = np.random.choice(len(X), min(5, len(X)), replace=False)
            
        for idx in sample_idx:
            net_input = self.net_input(X[idx])
            prob = self.sigmoid(net_input)
            plt.plot(net_input, prob, 'ro', label=f'Sample {idx} (y={y[idx]})')
            
        plt.grid(True)
        plt.legend()
        plt.xlabel('Net input')
        plt.ylabel('Probability')
        plt.title('Sigmoid Predictions')
        plt.show()

    def plot_decision_boundary(self, X, y, feature_idx=[0, 1]):
        """Plot decision boundary for 2D data"""
        # Set min and max values for the grid
        x1_min, x1_max = X[:, feature_idx[0]].min() - 1, X[:, feature_idx[0]].max() + 1
        x2_min, x2_max = X[:, feature_idx[1]].min() - 1, X[:, feature_idx[1]].max() + 1
        
        # Create a mesh grid
        xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, 0.1),
                              np.arange(x2_min, x2_max, 0.1))
        
        # Create feature matrix for prediction
        X_mesh = np.c_[xx1.ravel(), xx2.ravel()]
        if X.shape[1] > 2:
            # If more than 2 features, use zeros for other features
            X_mesh = np.hstack([X_mesh, np.zeros((X_mesh.shape[0], X.shape[1]-2))])
        
        # Make predictions
        Z = self.predict(X_mesh)
        Z = Z.reshape(xx1.shape)
        
        # Plot decision boundary
        plt.figure(figsize=(10, 6))
        plt.contourf(xx1, xx2, Z, alpha=0.4)
        plt.scatter(X[:, feature_idx[0]], X[:, feature_idx[1]], c=y, alpha=0.8)
        plt.xlabel(f'Feature {feature_idx[0]}')
        plt.ylabel(f'Feature {feature_idx[1]}')
        plt.title('Decision Boundary')
        plt.show()