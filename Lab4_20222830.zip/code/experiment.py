import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from LogisticRegressionSGD import LogisticRegressionSGD

plt.rcParams["font.sans-serif"] = ["SimHei"]  # Set font
plt.rcParams["axes.unicode_minus"] = False  # Solve the problem of "-" negative sign in the plot


def load_and_preprocess_data(file_path, is_iris=False):
    """
    Data loading and preprocessing function
    1. Load CSV file
    2. Extract features and target variable
    3. Encode target variable with label encoder
    4. Standardize features
    """
    df = pd.read_csv(file_path)

    # Extract features and target variable
    if is_iris:
        # Use all features for Iris dataset
        X = df.iloc[:, :-1].values
    else:
        # For RFID dataset, select the top 6 most important features
        selected_features = [
            'meanRSSI_1', 'meanRSSI_2', 'meanRSSI_3',  # Mean RSSI of three receivers
            'globalMeanRSSI', 'globalMaxRSSI', 'globalMeanStDev'  # Global features
        ]
        X = df[selected_features].values

    y = df.iloc[:, -1].values

    # Label encoding
    le = LabelEncoder()
    y = le.fit_transform(y)

    # Feature standardization
    sc = StandardScaler()
    X = sc.fit_transform(X)

    # For RFID dataset, limit the number of classes to speed up training
    if not is_iris:
        # Keep only the top 10 classes with the most samples
        unique_labels, counts = np.unique(y, return_counts=True)
        top_10_labels = unique_labels[np.argsort(counts)[-10:]]
        mask = np.isin(y, top_10_labels)
        X = X[mask]
        y = y[mask]
        # Re-encode labels to 0-9
        y = LabelEncoder().fit_transform(y)

    return X, y, le


def compare_models(X, y, feature_idx=[0, 1]):
    """
    Step 3 and Step 4: Compare custom logistic regression with scikit-learn implementation
    1. Split the dataset into training and testing sets
    2. Train two models
    3. Generate predictions
    4. Output classification reports
    5. Visualize decision boundaries
    """
    # Split the dataset
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Train the custom model
    print("Training custom logistic regression model...")
    custom_model = LogisticRegressionSGD(
        eta=0.01,  # Use a smaller learning rate for batch training
        n_iter=100,  # Increase the number of iterations to ensure convergence
        random_state=42,
        multi_class='ovr'
    )
    custom_model.fit(X_train, y_train)

    # Train the scikit-learn model
    print("Training scikit-learn logistic regression model...")
    sklearn_model = LogisticRegression(
        random_state=42,
        max_iter=50,  # Reduce the maximum number of iterations
        multi_class='ovr'
    )
    sklearn_model.fit(X_train, y_train)

    # Model predictions
    custom_pred = custom_model.predict(X_test)
    sklearn_pred = sklearn_model.predict(X_test)

    # Output classification reports
    print("\nCustom model performance evaluation:")
    print(classification_report(y_test, custom_pred))
    print("\nScikit-learn model performance evaluation:")
    print(classification_report(y_test, sklearn_pred))

    # Plot decision boundary comparison
    plt.figure(figsize=(15, 6))

    # Custom model decision boundary
    plt.subplot(1, 2, 1)
    custom_model.plot_decision_boundary(X_train, y_train, feature_idx)
    plt.title('Custom Model Decision Boundary')

    # Scikit-learn model decision boundary
    plt.subplot(1, 2, 2)
    plot_sklearn_decision_boundary(sklearn_model, X_train, y_train, feature_idx)
    plt.title('Scikit-learn Model Decision Boundary')

    plt.tight_layout()
    plt.show()

    return custom_model, sklearn_model


def plot_sklearn_decision_boundary(model, X, y, feature_idx=[0, 1]):
    """
    Plot decision boundary for scikit-learn model
    Use the same visualization method as the custom model
    """
    # Set grid range
    x1_min, x1_max = X[:, feature_idx[0]].min() - 1, X[:, feature_idx[0]].max() + 1
    x2_min, x2_max = X[:, feature_idx[1]].min() - 1, X[:, feature_idx[1]].max() + 1

    # Create grid
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, 0.1),
                           np.arange(x2_min, x2_max, 0.1))

    # Prepare feature matrix
    X_mesh = np.c_[xx1.ravel(), xx2.ravel()]

    # If the original number of features is greater than 2, fill other features with 0
    if X.shape[1] > 2:
        X_mesh_full = np.zeros((X_mesh.shape[0], X.shape[1]))
        X_mesh_full[:, feature_idx] = X_mesh
        X_mesh = X_mesh_full

    # Predict and plot
    Z = model.predict(X_mesh)
    Z = Z.reshape(xx1.shape)

    plt.contourf(xx1, xx2, Z, alpha=0.4)
    plt.scatter(X[:, feature_idx[0]], X[:, feature_idx[1]], c=y, alpha=0.8)
    plt.xlabel(f'Feature {feature_idx[0]}')
    plt.ylabel(f'Feature {feature_idx[1]}')


def main():
    """
    Main function: Execute all experimental steps in order
    1. Test on Iris dataset
    2. Visualize sigmoid prediction
    3. Benchmark test on RFID dataset
    """
    # Test on Iris dataset
    print("Testing on Iris dataset...")
    X_iris, y_iris, le_iris = load_and_preprocess_data('iris.csv', is_iris=True)
    custom_model_iris, _ = compare_models(X_iris, y_iris)

    # Visualize sigmoid prediction
    print("\nVisualizing sigmoid prediction...")
    custom_model_iris.plot_sigmoid_prediction(X_iris, y_iris)

    # Test on RFID dataset
    print("\nTesting on RFID dataset...")
    X_rfid, y_rfid, le_rfid = load_and_preprocess_data('all_w10_s1.csv', is_iris=False)
    compare_models(X_rfid, y_rfid)


if __name__ == "__main__":
    main()