import numpy as np
from numpy.random import seed
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["SimHei"]  # Set font
plt.rcParams["axes.unicode_minus"] = False  # Solve the problem of "-" negative sign in the plot


class LogisticRegressionSGD(object):
    """Logistic Regression classifier using Stochastic Gradient Descent.

    Parameters
    ------------
    eta : float     Learning rate (between 0.0 and 1.0)
    n_iter : int    Passes over the training dataset.
    shuffle : bool (default: True)
        Shuffles training data every epoch if True to prevent cycles.
    random_state : int (default: None)
        Set random state for shuffling and initializing the weights.
    multi_class : str (default: 'ovr')
        'ovr' for one-vs-rest strategy
    """

    def __init__(self, eta=0.01, n_iter=50, shuffle=True, random_state=None, multi_class='ovr'):
        self.eta = eta
        self.n_iter = n_iter
        self.shuffle = shuffle
        self.random_state = random_state
        self.multi_class = multi_class
        if random_state:
            np.random.seed(random_state)
        self.w_ = None
        self.cost_ = []

    def sigmoid(self, z):
        """Compute sigmoid activation"""
        # Clip z to avoid overflow
        z = np.clip(z, -250, 250)
        return 1.0 / (1.0 + np.exp(-z))

    def fit(self, X, y):
        """Fit training data.

        Parameters
        ----------
        X : {array-like}, shape = [n_samples, n_features]
            Training vectors
        y : array-like, shape = [n_samples]
            Target values

        Returns
        -------
        self : object
        """
        # Get unique classes
        self.classes_ = np.unique(y)
        n_classes = len(self.classes_)
        n_samples, n_features = X.shape

        # Initialize weights for each class with small random values
        self.w_ = np.random.normal(loc=0.0, scale=0.01, size=(n_classes, n_features + 1))

        # Add bias term to X
        X_bias = np.c_[np.ones((n_samples, 1)), X]

        # Mini-batch size
        batch_size = min(200, n_samples)
        n_batches = n_samples // batch_size

        # Training loop
        for _ in range(self.n_iter):
            if self.shuffle:
                idx = np.random.permutation(n_samples)
                X_bias = X_bias[idx]
                y = y[idx]

            cost = []
            # Mini-batch training
            for batch in range(n_batches):
                start = batch * batch_size
                end = start + batch_size
                X_batch = X_bias[start:end]
                y_batch = y[start:end]

                # One-vs-Rest strategy
                for i, cls in enumerate(self.classes_):
                    y_bin = np.where(y_batch == cls, 1, 0)

                    # Forward pass
                    output = self.sigmoid(np.dot(X_batch, self.w_[i]))

                    # Compute error and update weights
                    error = y_bin - output
                    self.w_[i] += self.eta * np.dot(X_batch.T, error)

                    # Compute cost
                    cost.append(-np.mean(y_bin * np.log(output + 1e-15) +
                                         (1 - y_bin) * np.log(1 - output + 1e-15)))

            avg_cost = np.mean(cost)
            self.cost_.append(avg_cost)

            # Early stopping if cost is very small
            if avg_cost < 1e-5:
                break

        return self

    def _update_weights(self, xi, target, class_idx):
        """Apply logistic regression learning rule to update the weights"""
        output = self.sigmoid(self.net_input(xi, class_idx))
        error = target - output

        # Update weights
        self.w_[class_idx, 1:] += self.eta * xi * error
        self.w_[class_idx, 0] += self.eta * error

        # Return log-loss
        cost = -target * np.log(output + 1e-15) - (1 - target) * np.log(1 - output + 1e-15)
        return cost

    def net_input(self, X, class_idx=None):
        """Calculate net input"""
        if class_idx is not None:
            return np.dot(X, self.w_[class_idx, 1:]) + self.w_[class_idx, 0]
        else:
            return np.dot(X, self.w_[:, 1:].T) + self.w_[:, 0]

    def predict_proba(self, X):
        """Return probability estimates for all classes"""
        probas = self.sigmoid(self.net_input(X))
        if len(probas.shape) == 1:
            probas = probas.reshape(-1, 1)
        # Normalize probabilities
        probas = probas / probas.sum(axis=1, keepdims=True)
        return probas

    def predict(self, X):
        """Return class labels"""
        probas = self.predict_proba(X)
        return self.classes_[np.argmax(probas, axis=1)]

    def score(self, X, y):
        """Return accuracy score"""
        return np.mean(self.predict(X) == y)

    def plot_sigmoid_prediction(self, X, y, sample_idx=None):
        """
        Step 2.3: Visualize sigmoid prediction
        1. Plot the standard sigmoid curve
        2. Mark the predicted probabilities of actual samples on the curve
        3. Show at most 5 samples
        """
        plt.figure(figsize=(10, 6))

        # Generate the standard sigmoid curve
        z = np.linspace(-10, 10, 1000)
        s = self.sigmoid(z)
        plt.plot(z, s, 'b-', label='Sigmoid Curve')

        # Plot actual prediction points
        if sample_idx is None:
            sample_idx = np.random.choice(len(X), min(5, len(X)), replace=False)

        for idx in sample_idx:
            net_input = self.net_input(X[idx])
            prob = self.sigmoid(net_input)
            plt.plot(net_input, prob, 'ro', label=f'Sample {idx} (y={y[idx]})')

        plt.grid(True)
        plt.legend()
        plt.xlabel('Net Input')
        plt.ylabel('Probability')
        plt.title('Sigmoid Prediction Visualization')
        plt.show()

    def plot_decision_boundary(self, X, y, feature_idx=[0, 1]):
        """
        Step 3: Visualize decision boundary
        1. Create a grid in the feature space
        2. Make predictions for grid points
        3. Plot the decision boundary and data points
        """
        # Select the two features to visualize
        X_vis = X[:, feature_idx]

        # Set grid range
        x1_min, x1_max = X_vis[:, 0].min() - 1, X_vis[:, 0].max() + 1
        x2_min, x2_max = X_vis[:, 1].min() - 1, X_vis[:, 1].max() + 1

        # Create grid
        xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, 0.1),
                               np.arange(x2_min, x2_max, 0.1))

        # Prepare feature matrix for grid points
        mesh_points = np.c_[xx1.ravel(), xx2.ravel()]

        # Create full feature matrix, filling unused features with 0
        X_mesh_full = np.zeros((mesh_points.shape[0], X.shape[1]))
        for i, idx in enumerate(feature_idx):
            X_mesh_full[:, idx] = mesh_points[:, i]

        # Predict and plot decision boundary
        Z = self.predict(X_mesh_full)
        Z = Z.reshape(xx1.shape)

        plt.contourf(xx1, xx2, Z, alpha=0.4)
        plt.scatter(X_vis[:, 0], X_vis[:, 1], c=y, alpha=0.8)
        plt.xlabel(f'Feature {feature_idx[0]}')
        plt.ylabel(f'Feature {feature_idx[1]}')
        plt.title('Decision Boundary')