import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
import matplotlib.font_manager as fm


# Set Chinese font
# def set_chinese_font():
#     """Set Chinese font with priority"""
#     fonts = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
#     for font in fonts:
#         try:
#             plt.rcParams['font.sans-serif'] = [font]
#             plt.rcParams['axes.unicode_minus'] = False
#             # Test whether Chinese characters can be displayed normally
#             plt.plot()
#             plt.title('Test')
#             plt.close()
#             print(f"Successfully set font: {font}")
#             return
#         except:
#             continue
#     print("Warning: No suitable Chinese font found, may display garbled characters")


class ExperimentVisualizer:
    def __init__(self):
        plt.style.use('seaborn')
        set_chinese_font()

    def plot_dataset_distribution(self, X, y, title, n_components=2):
        """
        Use PCA to reduce data to 2D and visualize the data distribution
        """
        # Use fewer samples for visualization to improve performance
        max_samples = 1000
        if X.shape[0] > max_samples:
            indices = np.random.choice(X.shape[0], max_samples, replace=False)
            X_subset = X[indices]
            y_subset = y[indices]
        else:
            X_subset = X
            y_subset = y

        pca = PCA(n_components=n_components)
        X_pca = pca.fit_transform(X_subset)

        plt.figure(figsize=(10, 6))
        scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y_subset, cmap='tab20')
        plt.colorbar(scatter)
        plt.title(f'{title} Data Distribution (After PCA)')
        plt.xlabel('First Principal Component')
        plt.ylabel('Second Principal Component')
        plt.show()

    def plot_performance_comparison(self, results_dict):
        """
        Plot performance comparison of different models on various datasets
        """
        metrics = ['accuracy', 'macro avg_precision', 'macro avg_recall', 'macro avg_f1-score']
        datasets = list(results_dict.keys())
        models = list(results_dict[datasets[0]].keys())

        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Model Performance Comparison', fontsize=16)

        for idx, metric in enumerate(metrics):
            ax = axes[idx // 2, idx % 2]
            data = []
            for dataset in datasets:
                for model in models:
                    report = results_dict[dataset][model]
                    # Convert string report to dictionary
                    report_lines = report.split('\n')
                    for line in report_lines:
                        if 'accuracy' in line:
                            accuracy = float(line.split()[-1])
                        if 'macro avg' in line:
                            values = line.split()
                            macro_metrics = {
                                'macro avg_precision': float(values[3]),
                                'macro avg_recall': float(values[4]),
                                'macro avg_f1-score': float(values[5])
                            }
                    value = accuracy if metric == 'accuracy' else macro_metrics[metric]
                    data.append({
                        'Dataset': dataset,
                        'Model': model,
                        'Value': value
                    })

            df = pd.DataFrame(data)
            sns.barplot(x='Dataset', y='Value', hue='Model', data=df, ax=ax)
            ax.set_title(f'{metric} Comparison')
            ax.set_xticklabels(ax.get_xticklabels(), rotation=45)

        plt.tight_layout()
        plt.show()

    def plot_parameter_tuning_results(self, param_name, param_values, scores, model_name, dataset_name):
        """
        Plot parameter tuning results
        """
        plt.figure(figsize=(10, 6))
        plt.plot(param_values, scores, 'o-', linewidth=2, markersize=8)
        plt.title(f'{model_name} {param_name} Tuning Results on {dataset_name}')
        plt.xlabel(param_name)
        plt.ylabel('Cross-Validation Score')
        plt.grid(True)
        plt.show()