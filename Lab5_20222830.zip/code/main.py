import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB, MultinomialNB
from sklearn.metrics import classification_report
import tensorflow as tf
import cv2
import os
from sklearn.datasets import fetch_lfw_people
from visualization import ExperimentVisualizer

# Set random seed to ensure reproducibility
np.random.seed(42)


class MLExperiment:
    def __init__(self):
        """
        Initialize the experiment class, creating containers to store datasets, models, and results.
        """
        self.datasets = {}
        self.models = {}
        self.results = {}
        self.visualizer = ExperimentVisualizer()

    def load_wine_data(self):
        """
        Step 1.1: Load the wine dataset
        - Read data from a CSV file
        - Handle missing values: fill with the mean
        - Standardize features: scale features using StandardScaler
        - Separate features and target variable
        """
        print("Loading wine dataset...")
        wine_data = pd.read_csv('winequality-white.csv', sep=';')

        # Check and handle missing values
        if wine_data.isnull().sum().any():
            wine_data = wine_data.fillna(wine_data.mean())

        # Separate features and target variable
        X_wine = wine_data.drop('quality', axis=1)
        y_wine = wine_data['quality']

        # Standardize features
        scaler = StandardScaler()
        X_wine_scaled = scaler.fit_transform(X_wine)

        self.datasets['wine'] = {
            'X': X_wine_scaled,
            'y': y_wine,
            'name': 'Wine Dataset',
            'feature_names': X_wine.columns
        }

        # Visualize data distribution
        self.visualizer.plot_dataset_distribution(X_wine_scaled, y_wine, 'Wine Dataset')

    def load_mnist_data(self):
        """
        Step 1.2: Load the MNIST handwritten digit dataset
        - Load data using tensorflow.keras
        - Data preprocessing:
          1. Flatten image data into 1D arrays
          2. Normalize pixel values to the range [0,1]
          3. Select a subset to reduce computational load
        """
        print("Loading MNIST dataset...")
        (X_mnist, y_mnist), _ = tf.keras.datasets.mnist.load_data()

        # Flatten image data
        X_mnist = X_mnist.reshape(X_mnist.shape[0], -1)

        # Normalize pixel values
        X_mnist = X_mnist / 255.0

        # Select a subset to reduce computational load
        n_samples = 5000
        indices = np.random.choice(X_mnist.shape[0], n_samples, replace=False)
        X_mnist = X_mnist[indices]
        y_mnist = y_mnist[indices]

        self.datasets['mnist'] = {
            'X': X_mnist,
            'y': y_mnist,
            'name': 'MNIST Dataset'
        }

        # Visualize data distribution
        self.visualizer.plot_dataset_distribution(X_mnist, y_mnist, 'MNIST Dataset')

    def load_lfw_data(self):
        """
        Step 1.3: Load the LFW face dataset
        - Load data from a local directory
        - Data preprocessing:
          1. Resize images to a uniform size (50x50)
          2. Convert to grayscale
          3. Flatten images
          4. Standardize features
          5. Filter out classes with too few samples
        """
        print("Loading LFW face dataset...")

        # Load data from a local directory
        lfw_dir = 'lfw'
        X = []
        y = []
        target_names = []

        # Iterate through all person directories
        for person_name in os.listdir(lfw_dir):
            person_dir = os.path.join(lfw_dir, person_name)
            if os.path.isdir(person_dir):
                target_names.append(person_name)
                # Iterate through all images of the person
                for image_name in os.listdir(person_dir):
                    if image_name.endswith('.jpg'):
                        image_path = os.path.join(person_dir, image_name)
                        # Read and resize the image
                        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
                        if image is not None:
                            image = cv2.resize(image, (50, 50))  # Resize to a uniform size
                            X.append(image.flatten())  # Flatten the image
                            y.append(len(target_names) - 1)  # Use index as label

        # Convert to numpy arrays
        X = np.array(X)
        y = np.array(y)

        # Ensure sufficient samples
        min_samples = 10
        valid_classes = np.where(np.bincount(y) >= min_samples)[0]
        mask = np.isin(y, valid_classes)
        X = X[mask]
        y = y[mask]

        # Update target names
        target_names = [target_names[i] for i in valid_classes]

        # Standardize features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        self.datasets['lfw'] = {
            'X': X_scaled,
            'y': y,
            'name': 'LFW Face Dataset',
            'target_names': target_names
        }

        print(f"Loading complete: {len(target_names)} person classes, {len(y)} images")

        # Visualize data distribution
        self.visualizer.plot_dataset_distribution(X_scaled, y, 'LFW Face Dataset')

    def train_and_evaluate(self, dataset_name):
        """
        Step 2: Train and evaluate multiple classifiers
        - Implement three classifiers:
          1. KNN Classifier
          2. Decision Tree Classifier
          3. Naive Bayes Classifier
        - Evaluate performance using cross-validation
        - Generate classification reports, including:
          * Accuracy
          * Precision
          * Recall
          * F1-score
        """
        print(f"\nTraining and evaluating models for {dataset_name}...")
        X = self.datasets[dataset_name]['X']
        y = self.datasets[dataset_name]['y']

        # Split into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

        # Initialize classifiers
        classifiers = {
            'KNN': KNeighborsClassifier(),
            'Decision Tree': DecisionTreeClassifier(random_state=42),
            'Naive Bayes': GaussianNB()
        }

        # Train and evaluate each classifier
        for name, clf in classifiers.items():
            print(f"\nTraining {name}...")
            clf.fit(X_train, y_train)
            y_pred = clf.predict(X_test)

            # Save results
            if dataset_name not in self.results:
                self.results[dataset_name] = {}
            self.results[dataset_name][name] = classification_report(y_test, y_pred)

            print(f"Classification report for {name}:")
            print(self.results[dataset_name][name])

    def parameter_tuning(self, dataset_name):
        """
        Step 3: Hyperparameter tuning
        - Use GridSearchCV to optimize parameters for each model:
          1. KNN: Tune different k values and weights
          2. Decision Tree: Tune splitting criteria (Gini/Entropy) and tree depth
          3. Naive Bayes: Tune smoothing parameters
        - Evaluate performance of different parameter combinations using cross-validation
        - Select the best parameter combination
        """
        print(f"\nHyperparameter tuning for {dataset_name}...")
        X = self.datasets[dataset_name]['X']
        y = self.datasets[dataset_name]['y']

        # Downsample large datasets to speed up tuning
        max_samples = 5000
        if X.shape[0] > max_samples:
            indices = np.random.choice(X.shape[0], max_samples, replace=False)
            X = X[indices]
            y = y[indices]

        # KNN parameter grid
        knn_param_grid = {
            'n_neighbors': [3, 5, 7],
            'weights': ['uniform', 'distance'],
            'metric': ['euclidean']
        }

        # Decision Tree parameter grid
        dt_param_grid = {
            'criterion': ['gini', 'entropy'],
            'max_depth': [5, 10, 15],
            'min_samples_split': [2, 5]
        }

        # Naive Bayes parameter grid
        nb_param_grid = {
            'var_smoothing': np.logspace(-9, -8, 3)
        }

        try:
            # Set temporary environment variable to handle Chinese path issues
            import os
            import tempfile

            # Use system temporary directory as working directory
            temp_dir = tempfile.gettempdir()
            os.environ['JOBLIB_TEMP_FOLDER'] = temp_dir

            # Perform grid search
            for name, (clf, param_grid) in {
                'KNN': (KNeighborsClassifier(), knn_param_grid),
                'Decision Tree': (DecisionTreeClassifier(random_state=42), dt_param_grid),
                'Naive Bayes': (GaussianNB(), nb_param_grid)
            }.items():
                print(f"\nPerforming grid search for {name}...")
                grid_search = GridSearchCV(
                    clf,
                    param_grid,
                    cv=3,  # Reduce cross-validation folds
                    n_jobs=1,  # Use single-thread to avoid parallel processing issues
                    scoring='accuracy',
                    verbose=1
                )
                grid_search.fit(X, y)

                print(f"\nBest parameters: {grid_search.best_params_}")
                print(f"Best score: {grid_search.best_score_:.4f}")

                # Visualize parameter tuning results
                if name == 'KNN':
                    k_values = knn_param_grid['n_neighbors']
                    k_scores = []
                    for i, params in enumerate(grid_search.cv_results_['params']):
                        if params['weights'] == 'uniform' and params['metric'] == 'euclidean':
                            k_scores.append(grid_search.cv_results_['mean_test_score'][i])
                    if k_scores:
                        self.visualizer.plot_parameter_tuning_results(
                            'n_neighbors', k_values, k_scores, name, dataset_name
                        )

        except Exception as e:
            print(f"Warning: An error occurred during hyperparameter tuning: {str(e)}")
            print("Continuing with other steps...")


def main():
    """
    Main function: Execute the complete experiment workflow according to the experimental steps
    1. Load and preprocess three datasets
    2. Train and evaluate three classifiers
    3. Perform hyperparameter tuning
    4. Visualize comparison results
    """
    experiment = MLExperiment()

    # Step 1: Load datasets
    experiment.load_wine_data()
    experiment.load_mnist_data()
    experiment.load_lfw_data()

    # Step 2: Train and evaluate for each dataset
    for dataset_name in experiment.datasets.keys():
        experiment.train_and_evaluate(dataset_name)

    # Step 3: Perform parameter tuning for each dataset
    for dataset_name in experiment.datasets.keys():
        experiment.parameter_tuning(dataset_name)

    # Plot performance comparison for all models
    experiment.visualizer.plot_performance_comparison(experiment.results)


if __name__ == "__main__":
    main()