import MLP
import os
import struct
import torch
import numpy as np
import matplotlib.pyplot as plt
import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
#import MLP_test_multi as MLP
from scipy.io import arff
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
plt.rcParams["font.family"] = ["Times New Roman", "SimSun"]

file_path = "all_w10_s1.arff"
data, meta = arff.loadarff(file_path)
df = pd.DataFrame(data)

def convert_binary_strings(df):
    for column in df.columns:
        if df[column].dtype == object:
            df[column] = df[column].str.decode('utf-8')
    return df
df = convert_binary_strings(df)

scaler = StandardScaler()

X = df.iloc[:, :-1].values  
y = df.iloc[:, -1].values   


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

n_components = 50
pca = PCA(n_components=n_components)
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)

from sklearn.preprocessing import LabelEncoder
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(y_train)
y_test = label_encoder.transform(y_test)
print(y_train)
# def load_mnist(path, kind='train'):
#     labels_path = os.path.join(path, '%s-labels-idx1-ubyte' % kind)
#     images_path = os.path.join(path, '%s-images-idx3-ubyte' % kind)

#     with open(labels_path, 'rb') as lbpath:
#         magic, n = struct.unpack('>II', lbpath.read(8))
#         labels = np.fromfile(lbpath, dtype=np.uint8)

#     with open(images_path, 'rb') as imgpath:
#         magic, num, rows, cols = struct.unpack(">IIII", imgpath.read(16))
#         images = np.fromfile(imgpath, dtype=np.uint8).reshape(len(labels), 784)

#     return images, labels


# X_train, y_train = load_mnist('D:/', kind='train')
# X_test, y_test = load_mnist('D:/', kind='t10k')



nn = MLP.NeuralNetMLP(n_output=len(label_encoder.classes_),
                  n_features=X_train_pca.shape[1],
                  n_hidden=50,
                  l2=0.1,
                  l1=0.0,
                  epochs=1000,
                  eta=0.001,
                  alpha=0.001,
                  decrease_const=0.00001,
                  minibatches=100,
                  shuffle=True,
                  random_state=1)

#nn.fit(X_train, y_train, print_progress=True)
nn.fit(X_train_pca, y_train,print_progress=True)

y_train_pred = nn.predict(X_train_pca)
acc = np.sum(y_train == y_train_pred, axis=0) / X_train_pca.shape[0]
print('Training accuracy: %.2f%%' % (acc * 100))

y_test_pred = nn.predict(X_test_pca)
acc = np.sum(y_test == y_test_pred, axis=0) / X_test_pca.shape[0]
print('Test accuracy: %.2f%%' % (acc * 100))

plt.plot(range(len(nn.cost_)), nn.cost_)
plt.ylim([0,4000])
plt.ylabel('Cost')
plt.xlabel('Epochs')
plt.tight_layout()
plt.savefig('cost.png', dpi=300)


