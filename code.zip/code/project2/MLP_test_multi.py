import numpy as np
from scipy.special import expit
import sys

class NeuralNetMLP(object):
    """ Feedforward neural network / Multi-layer perceptron classifier with arbitrary layers. """

    def __init__(self, n_output, n_features, n_hidden_layers=3, n_hidden=30, l1=0.0, l2=0.0, epochs=500, eta=0.001,
                 alpha=0.0, decrease_const=0.0, shuffle=True, minibatches=1, random_state=None, activation='relu'):
        np.random.seed(random_state)
        self.n_output = n_output
        self.n_features = n_features
        self.n_hidden_layers = n_hidden_layers
        self.n_hidden = n_hidden
        self.l1 = l1
        self.l2 = l2
        self.epochs = epochs
        self.eta = eta
        self.alpha = alpha
        self.decrease_const = decrease_const
        self.shuffle = shuffle
        self.minibatches = minibatches
        self.activation = activation
        self.weights = self._initialize_weights()

    def _initialize_weights(self):
        """ Initialize weights for each layer """
        all_weights = []
        prev_layer_size = self.n_features

        # Initialize weights for hidden layers
        for _ in range(self.n_hidden_layers):
            weights = np.random.uniform(-1.0, 1.0, size=(self.n_hidden, prev_layer_size + 1))
            all_weights.append(weights)
            prev_layer_size = self.n_hidden

        # Initialize weights for output layer
        w_output = np.random.uniform(-1.0, 1.0, size=(self.n_output, prev_layer_size + 1))
        all_weights.append(w_output)

        return all_weights

    def _add_bias_unit(self, X, how='column'):
        """ Add bias unit (column or row of 1s) to array at index 0 """
        if how == 'column':
            X_new = np.ones((X.shape[0], X.shape[1] + 1))
            X_new[:, 1:] = X
        elif how == 'row':
            X_new = np.ones((X.shape[0] + 1, X.shape[1]))
            X_new[1:, :] = X
        else:
            raise AttributeError('`how` must be `column` or `row`')
        return X_new

    def _activation_function(self, z):
        """ Apply the activation function for a given layer. """
        if self.activation == 'relu':
            return np.maximum(0, z)
        elif self.activation == 'sigmoid':
            return expit(z)
        else:
            raise ValueError("Unsupported activation function")

    def _activation_derivative(self, z):
        """ Return the derivative of the activation function. """
        if self.activation == 'relu':
            return (z > 0).astype(float)
        elif self.activation == 'sigmoid':
            sg = expit(z)
            return sg * (1.0 - sg)
        else:
            raise ValueError("Unsupported activation function")

    def _feedforward(self, X):
        """ Compute feedforward step """
        a = self._add_bias_unit(X, how='column')
        activations = [a]

        for i in range(self.n_hidden_layers):
            z = self.weights[i].dot(a.T)
            a = self._activation_function(z)
            a = self._add_bias_unit(a, how='row')
            activations.append(a)

        z_output = self.weights[-1].dot(a)
        a_output = expit(z_output)  # Output layer uses sigmoid by default
        activations.append(a_output)

        return activations

    def _get_gradient(self, activations, y_enc):
        """ Compute gradient step using backpropagation """
        # Output layer error
        sigma_output = activations[-1] - y_enc
        sigma = [sigma_output]

        # Backpropagate through hidden layers
        for i in range(self.n_hidden_layers, 0, -1):
            sigma_hidden = self.weights[i].T.dot(sigma[-1]) * self._activation_derivative(activations[i])
            sigma_hidden = sigma_hidden[1:, :]  # Remove bias
            sigma.append(sigma_hidden)

        sigma.reverse()

        # Compute gradients
        grad = []
        for i in range(self.n_hidden_layers + 1):
            grad_w = sigma[i].dot(activations[i].T)
            grad.append(grad_w)

        # Regularize
        for i in range(self.n_hidden_layers + 1):
            grad[i][:, 1:] += self.l2 * self.weights[i][:, 1:]
            grad[i][:, 1:] += self.l1 * np.sign(self.weights[i][:, 1:])

        return grad

    def _get_cost(self, y_enc, activations):
        """ Compute cost function """
        output = activations[-1]
        term1 = -y_enc * np.log(output)
        term2 = (1.0 - y_enc) * np.log(1.0 - output)
        cost = np.sum(term1 - term2)
        L1_term = self._L1_reg(self.l1)
        L2_term = self._L2_reg(self.l2)
        return cost + L1_term + L2_term

    def _L2_reg(self, lambda_):
        """ Compute L2-regularization cost """
        return (lambda_ / 2.0) * sum(np.sum(w[:, 1:] ** 2) for w in self.weights)

    def _L1_reg(self, lambda_):
        """ Compute L1-regularization cost """
        return (lambda_ / 2.0) * sum(np.abs(w[:, 1:]).sum() for w in self.weights)

    def fit(self, X, y, print_progress=False):
        """ Learn weights from training data """
        self.cost_ = []
        y_enc = self._encode_labels(y, self.n_output)
        delta_weights_prev = [np.zeros(w.shape) for w in self.weights]

        for i in range(self.epochs):
            self.eta /= (1 + self.decrease_const * i)

            if print_progress:
                sys.stderr.write('\rEpoch: %d/%d' % (i + 1, self.epochs))
                sys.stderr.flush()

            if self.shuffle:
                idx = np.random.permutation(y.shape[0])
                X, y_enc = X[idx], y_enc[:, idx]

            mini = np.array_split(range(y.shape[0]), self.minibatches)
            for idx in mini:
                activations = self._feedforward(X[idx])
                cost = self._get_cost(y_enc[:, idx], activations)
                self.cost_.append(cost)

                gradients = self._get_gradient(activations, y_enc[:, idx])

                for i in range(self.n_hidden_layers + 1):
                    delta_weights = self.eta * gradients[i]
                    self.weights[i] -= delta_weights + (self.alpha * delta_weights_prev[i])
                    delta_weights_prev[i] = delta_weights

        return self

    def partial_fit(self, X, y, epochs=1):
        """ Continue training from the existing model """
        y_enc = self._encode_labels(y, self.n_output)
        delta_weights_prev = [np.zeros(w.shape) for w in self.weights]

        for epoch in range(epochs):
            self.eta /= (1 + self.decrease_const * epoch)

            if self.shuffle:
                idx = np.random.permutation(y.shape[0])
                X, y_enc = X[idx], y_enc[:, idx]

            mini = np.array_split(range(y.shape[0]), self.minibatches)
            for idx in mini:
                activations = self._feedforward(X[idx])
                cost = self._get_cost(y_enc[:, idx], activations)
                self.cost_.append(cost)

                gradients = self._get_gradient(activations, y_enc[:, idx])

                for i in range(self.n_hidden_layers + 1):
                    delta_weights = self.eta * gradients[i]
                    self.weights[i] -= delta_weights + (self.alpha * delta_weights_prev[i])
                    delta_weights_prev[i] = delta_weights

        return self

    def _encode_labels(self, y, k):
        """ Encode labels into one-hot representation """
        onehot = np.zeros((k, y.shape[0]))
        for idx, val in enumerate(y):
            onehot[val, idx] = 1.0
        return onehot

    def predict(self, X):
        """ Predict class labels """
        activations = self._feedforward(X)
        return np.argmax(activations[-1], axis=0)
