import numpy as np
from numpy.random import seed
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score


class AdalineSGD(object):
    """ADAptive LInear NEuron classifier.

    Parameters
    ------------
    eta : float     Learning rate (between 0.0 and 1.0)
    n_iter : int    Passes over the training dataset.

    Attributes
    -----------
    w_ : 1d-array   Weights after fitting.
    cost_ : list
        Sum-of-squares cost function value averaged over all
        training samples in each epoch.
    shuffle : bool (default: True)
        Shuffles training data every epoch if True to prevent cycles.
    random_state : int (default: None)
        Set random state for shuffling and initializing the weights.
    """

    def __init__(self, eta=0.01, n_iter=10, shuffle=True, random_state=None):
        self.eta = eta
        self.n_iter = n_iter
        self.w_initialized = False
        self.shuffle = shuffle
        if random_state:
            seed(random_state)

    def fit(self, X, y):
        """ Fit training data.

        Parameters
        ----------
        X : {array-like}, shape = [n_samples, n_features]
            Training vectors, where n_samples is the number of samples and
            n_features is the number of features.
        y : array-like, shape = [n_samples]
            Target values.

        Returns
        -------
        self : object
        """
        self._initialize_weights(X.shape[1])
        self.cost_ = []
        for i in range(self.n_iter):
            if self.shuffle:
                X, y = self._shuffle(X, y)
            cost = []
            for xi, target in zip(X, y):
                cost.append(self._update_weights(xi, target))

            avg_cost = sum(cost) / len(y)
            self.cost_.append(avg_cost)
        return self

    def partial_fit(self, X, y):
        """Fit training data without reinitializing the weights"""
        if not self.w_initialized:
            self._initialize_weights(X.shape[1])
        if y.ravel().shape[0] > 1:
            for xi, target in zip(X, y):
                self._update_weights(xi, target)
        else:
            self._update_weights(X, y)
        return self

    def _shuffle(self, X, y):
        """Shuffle training data"""
        r = np.random.permutation(len(y))
        return X[r], y[r]

    def _initialize_weights(self, m):
        """Initialize weights to zeros"""
        self.w_ = np.zeros(1 + m)
        self.w_initialized = True

    def _update_weights(self, xi, target):
        """Apply Adaline learning rule to update the weights"""
        output = self.net_input(xi)
        error = (target - output)
        self.w_[1:] += self.eta * xi.dot(error)
        self.w_[0] += self.eta * error
        cost = 0.5 * error ** 2
        return cost

    def net_input(self, X):
        """Calculate net input"""
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def activation(self, X):
        """Compute linear activation"""
        return self.net_input(X)

    def predict(self, X):
        """Return class label after unit step"""
        return np.where(self.activation(X) >= 0.0, 1, -1)


def binary_classification_test():
    """Test the original Adaline on a simple binary classification problem"""
    print("\n===== Step 1: Understand Adaline code and perform binary classification test =====")

    # Generate a simple binary classification dataset
    X, y = make_classification(n_samples=100, n_features=2, n_redundant=0,
                               n_informative=2, random_state=42, n_clusters_per_class=1)

    # Convert labels to 1 and -1
    y = np.where(y == 0, -1, 1)

    # Standardize features
    sc = StandardScaler()
    X_std = sc.fit_transform(X)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X_std, y, test_size=0.3, random_state=42)

    # Train model
    print("Training Adaline SGD model for binary classification...")
    adaline = AdalineSGD(eta=0.01, n_iter=15, random_state=42)
    adaline.fit(X_train, y_train)

    # Predict and evaluate
    y_pred = adaline.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Binary classification accuracy: {accuracy:.4f}")

    # Plot classification results
    plt.figure(figsize=(10, 6))

    # Plot decision boundary
    x_min, x_max = X_test[:, 0].min() - 1, X_test[:, 0].max() + 1
    y_min, y_max = X_test[:, 1].min() - 1, X_test[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.02),
                         np.arange(y_min, y_max, 0.02))
    Z = adaline.predict(np.array([xx.ravel(), yy.ravel()]).T)
    Z = Z.reshape(xx.shape)
    plt.contourf(xx, yy, Z, alpha=0.3, cmap='viridis')

    # Plot data points
    plt.scatter(X_test[:, 0], X_test[:, 1], c=y_test, marker='o', alpha=0.8,
                cmap='viridis', edgecolors='k', s=100)

    plt.title('Adaline SGD Binary Classification')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.grid(True)
    plt.show()

    # Plot cost function
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, len(adaline.cost_) + 1), adaline.cost_, marker='o')
    plt.xlabel('Epochs')
    plt.ylabel('Average Cost')
    plt.title('Adaline SGD - Cost per Epoch')
    plt.grid(True)
    plt.show()

    return adaline


if __name__ == "__main__":
    # Run binary classification test
    binary_classification_test()
