import numpy as np
import matplotlib.pyplot as plt
from numpy.random import seed
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
import time


# ----- AdalineSGD: Standard Stochastic Gradient Descent -----
class AdalineSGD(object):
    """ADAptive LInear NEuron classifier using Stochastic Gradient Descent.

    Parameters:
        eta : float
            Learning rate (between 0.0 and 1.0).
        n_iter : int
            Number of passes over the training dataset.
        shuffle : bool (default: True)
            Shuffles training data every epoch to prevent cycles.
        random_state : int (default: None)
            Seed for shuffling and initializing the weights.
    """

    def __init__(self, eta=0.01, n_iter=10, shuffle=True, random_state=None):
        self.eta = eta
        self.n_iter = n_iter
        self.shuffle = shuffle
        self.w_initialized = False
        if random_state:
            seed(random_state)

    def fit(self, X, y):
        """Fit training data."""
        self._initialize_weights(X.shape[1])
        self.cost_ = []
        for i in range(self.n_iter):
            if self.shuffle:
                X, y = self._shuffle(X, y)
            cost = []
            for xi, target in zip(X, y):
                cost.append(self._update_weights(xi, target))
            err = sum(cost)
            self.cost_.append(err)
        return self

    def partial_fit(self, X, y):
        if not self.w_initialized:
            self._initialize_weights(X.shape[1])
        if y.ravel().shape[0] > 1:
            for xi, target in zip(X, y):
                self._update_weights(xi, target)
        else:
            self._update_weights(X, y)
        return self

    def _shuffle(self, X, y):
        r = np.random.permutation(len(y))
        return X[r], y[r]

    def _initialize_weights(self, m):
        self.w_ = np.zeros(1 + m)
        self.w_initialized = True

    def _update_weights(self, xi, target):
        output = self.net_input(xi)
        error = (target - output)
        self.w_[1:] += self.eta * xi.dot(error)
        self.w_[0] += self.eta * error
        cost = 0.5 * error ** 2
        return cost

    def net_input(self, X):
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def activation(self, X):
        return self.net_input(X)

    def predict(self, X):
        return np.where(self.activation(X) >= 0.0, 1, -1)


# ----- AdalineMiniBatch: Mini-batch Gradient Descent -----
class AdalineMiniBatch(object):
    """
    ADAptive LInear NEuron classifier with mini-batch gradient descent.

    Parameters:
        eta : float
            Learning rate.
        n_iter : int
            Number of epochs.
        batch_size : int
            Size of mini-batches.
        shuffle : bool (default: True)
            Shuffles training data at each epoch.
        random_state : int (default: None)
            Seed for reproducibility.

    Attributes:
        w_ : 1d-array
            Weights after fitting.
        cost_ : list
            Sum-of-squares cost value for each epoch.
    """

    def __init__(self, eta=0.01, n_iter=10, batch_size=32, shuffle=True, random_state=None):
        self.eta = eta
        self.n_iter = n_iter
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.random_state = random_state
        self.w_initialized = False
        if random_state:
            seed(random_state)

    def fit(self, X, y):
        """Fit training data using mini-batch gradient descent."""
        self._initialize_weights(X.shape[1])
        self.cost_ = []
        n_samples = X.shape[0]
        for epoch in range(self.n_iter):
            if self.shuffle:
                X, y = self._shuffle(X, y)
            epoch_cost = 0.0
            # 分割数据为 mini-batch
            for i in range(0, n_samples, self.batch_size):
                X_batch = X[i:i + self.batch_size]
                y_batch = y[i:i + self.batch_size]
                output = self.net_input(X_batch)
                errors = y_batch - output
                # 使用 mini-batch 更新权重
                self.w_[1:] += self.eta * X_batch.T.dot(errors)
                self.w_[0] += self.eta * errors.sum()
                cost_batch = 0.5 * (errors ** 2).sum()
                epoch_cost += cost_batch
            self.cost_.append(epoch_cost)
        return self

    def _shuffle(self, X, y):
        r = np.random.permutation(len(y))
        return X[r], y[r]

    def _initialize_weights(self, m):
        self.w_ = np.zeros(1 + m)
        self.w_initialized = True

    def net_input(self, X):
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def activation(self, X):
        return self.net_input(X)

    def predict(self, X):
        return np.where(self.activation(X) >= 0.0, 1, -1)


# ----- Testing function: Analyze training time and accuracy -----
def test_minibatch_adaline():
    # 生成一个简单的二分类数据集
    X, y = make_classification(n_samples=500, n_features=2, n_redundant=0,
                               n_informative=2, random_state=42, n_clusters_per_class=1)
    # 转换标签为 1 和 -1
    y = np.where(y == 0, -1, 1)

    # 标准化特征
    scaler = StandardScaler()
    X_std = scaler.fit_transform(X)

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X_std, y, test_size=0.3, random_state=42)

    # 使用 AdalineSGD 进行训练（逐样本更新）
    model_sgd = AdalineSGD(eta=0.01, n_iter=50, random_state=42)
    start_time = time.time()
    model_sgd.fit(X_train, y_train)
    time_sgd = time.time() - start_time
    y_pred_sgd = model_sgd.predict(X_test)
    accuracy_sgd = accuracy_score(y_test, y_pred_sgd)

    # 使用 AdalineMiniBatch 进行训练（小批量更新）
    model_mb = AdalineMiniBatch(eta=0.01, n_iter=50, batch_size=32, random_state=42)
    start_time = time.time()
    model_mb.fit(X_train, y_train)
    time_mb = time.time() - start_time
    y_pred_mb = model_mb.predict(X_test)
    accuracy_mb = accuracy_score(y_test, y_pred_mb)

    print("AdalineSGD (Stochastic Gradient Descent):")
    print(f"  Training time: {time_sgd:.4f} seconds")
    print(f"  Test accuracy: {accuracy_sgd:.4f}")

    print("\nAdalineMiniBatch (Mini-batch Gradient Descent):")
    print(f"  Training time: {time_mb:.4f} seconds")
    print(f"  Test accuracy: {accuracy_mb:.4f}")

    # 绘制两个模型的成本曲线
    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    ax[0].plot(range(1, len(model_sgd.cost_) + 1), model_sgd.cost_, marker='o')
    ax[0].set_title('AdalineSGD - Cost per Epoch')
    ax[0].set_xlabel('Epochs')
    ax[0].set_ylabel('Sum-squared-error')

    ax[1].plot(range(1, len(model_mb.cost_) + 1), model_mb.cost_, marker='o')
    ax[1].set_title('AdalineMiniBatch - Cost per Epoch')
    ax[1].set_xlabel('Epochs')
    ax[1].set_ylabel('Sum-squared-error')

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    test_minibatch_adaline()
