import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn import datasets
import scipy.io.arff as arff
from joblib import Parallel, delayed
from numba import jit

# Set encoding to avoid issues with non-ASCII characters
os.environ["PYTHONIOENCODING"] = "utf-8"

# ------------------------- Basic Binary Adaline (using SGD) -------------------------
class AdalineSGD:
    def __init__(self, eta=0.01, n_iter=10, shuffle=True, random_state=None):
        self.eta = eta
        self.n_iter = n_iter
        self.shuffle = shuffle
        self.random_state = random_state
        self.w_initialized = False

    def _initialize_weights(self, m):
        self.rgen = np.random.RandomState(self.random_state)
        # Randomly initialize weights with small values
        self.w_ = self.rgen.normal(loc=0.0, scale=0.01, size=1 + m)
        self.w_initialized = True

    def _shuffle(self, X, y):
        indices = self.rgen.permutation(len(y))
        return X[indices], y[indices]

    def _activation(self, X):
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def _update_weights_batch(self, X_batch, y_batch):
        output = self._activation(X_batch)
        errors = y_batch - output
        # Vectorized weight update using the mini-batch
        self.w_[1:] += self.eta * X_batch.T.dot(errors) / len(y_batch)
        self.w_[0] += self.eta * np.mean(errors)
        return 0.5 * np.mean(errors ** 2)

    def fit(self, X, y):
        self._initialize_weights(X.shape[1])
        self.cost_ = []
        for i in range(self.n_iter):
            if self.shuffle:
                X, y = self._shuffle(X, y)
            cost = self._update_weights_batch(X, y)
            self.cost_.append(cost)
        return self

    def partial_fit(self, X, y):
        if not self.w_initialized:
            self._initialize_weights(X.shape[1])
        self._update_weights_batch(X, y)
        return self

    def predict(self, X):
        return np.where(self._activation(X) >= 0.0, 1, -1)


# ------------------------- Multi-Class Adaline (One-vs-All Strategy) -------------------------
class MultiAdaline:
    def __init__(self, eta=0.01, n_iter=10, shuffle=True, random_state=None, n_jobs=-1):
        self.eta = eta
        self.n_iter = n_iter
        self.shuffle = shuffle
        self.random_state = random_state
        self.n_jobs = n_jobs  # Number of parallel jobs (-1 uses all cores)
        self.classifiers_ = {}

    def _train_single(self, label, X, y):
        # Create binary target: current class as 1, others as -1
        y_bin = np.where(y == label, 1, -1)
        clf = AdalineSGD(eta=self.eta, n_iter=self.n_iter,
                         shuffle=self.shuffle, random_state=self.random_state)
        clf.fit(X, y_bin)
        return label, clf

    def fit(self, X, y):
        self.classes_ = np.unique(y)
        results = Parallel(n_jobs=self.n_jobs)(
            delayed(self._train_single)(lab, X, y) for lab in self.classes_
        )
        for lab, clf in results:
            self.classifiers_[lab] = clf
        return self

    def predict_activations(self, X):
        activations = np.zeros((X.shape[0], len(self.classes_)))
        for idx, lab in enumerate(self.classes_):
            activations[:, idx] = self.classifiers_[lab]._activation(X)
        return activations

    def predict(self, X):
        acts = self.predict_activations(X)
        max_idx = np.argmax(acts, axis=1)
        return self.classes_[max_idx]


# ------------------------- Numba-Accelerated Numerical Preprocessing -------------------------
@jit(nopython=True)
def numba_preprocess(X):
    return X


# ------------------------- Data Loading and Preprocessing -------------------------
def load_iris_dataset():
    iris = datasets.load_iris()
    X, y = iris.data, iris.target
    print(f"Iris dataset: {X.shape[0]} samples, {X.shape[1]} features, {len(np.unique(y))} classes")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,
                                                        random_state=1, stratify=y)
    scaler = StandardScaler()
    X_train_std = scaler.fit_transform(X_train)
    X_test_std = scaler.transform(X_test)
    X_train_std = numba_preprocess(X_train_std)
    X_test_std = numba_preprocess(X_test_std)
    return X_train_std, X_test_std, y_train, y_test, iris.target_names

def load_rfid_dataset(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"RFID data file not found: {file_path}")
    data, meta = arff.loadarff(file_path)
    df = pd.DataFrame(data)
    print(f"RFID dataset: {df.shape[0]} samples, {df.shape[1]} features")
    # Process the target column: use 'class' if available, otherwise assume the last column
    target_col = 'class' if 'class' in df.columns else df.columns[-1]
    if df[target_col].dtype == 'object':
        df[target_col] = df[target_col].map(lambda x: x.decode('utf-8') if isinstance(x, bytes) else x)
    X = df.drop(target_col, axis=1).values
    y = df[target_col].values
    le = LabelEncoder()
    y = le.fit_transform(y)
    print(f"RFID number of classes: {len(le.classes_)}")
    # Replace missing values with column means
    X = np.nan_to_num(X, nan=np.nanmean(X, axis=0))
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,
                                                        random_state=1, stratify=y)
    scaler = StandardScaler()
    X_train_std = scaler.fit_transform(X_train)
    X_test_std = scaler.transform(X_test)
    X_train_std = numba_preprocess(X_train_std)
    X_test_std = numba_preprocess(X_test_std)
    return X_train_std, X_test_std, y_train, y_test, le.classes_


# ------------------------- Model Evaluation Function -------------------------
def evaluateClassifier(model, X_train, X_test, y_train, y_test, class_names=None, verbose=True):
    start_time = time.time()
    model.fit(X_train, y_train)
    train_time = time.time() - start_time

    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)

    train_acc = accuracy_score(y_train, y_train_pred)
    test_acc = accuracy_score(y_test, y_test_pred)
    conf_mat = confusion_matrix(y_test, y_test_pred)
    if class_names is not None:
        target_labels = [str(name) for name in class_names]
        report = classification_report(y_test, y_test_pred, target_names=target_labels, output_dict=True)
    else:
        report = classification_report(y_test, y_test_pred, output_dict=True)

    if verbose:
        print(f"Training time: {train_time:.4f} seconds")
        print(f"Training accuracy: {train_acc:.4f}")
        print(f"Test accuracy: {test_acc:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_test, y_test_pred,
              target_names=target_labels if class_names is not None else None))
    return {
        'train_time': train_time,
        'train_accuracy': train_acc,
        'test_accuracy': test_acc,
        'confusion_matrix': conf_mat,
        'classification_report': report
    }


# ------------------------- Performance Comparison and Visualization -------------------------
def comparePerformance(rfid_path="all_w10_s1.arff"):
    # Model parameters
    model_params = {'eta': 0.01, 'n_iter': 50, 'random_state': 1, 'n_jobs': 1}

    # Load Iris dataset
    Xtr_iris, Xte_iris, ytr_iris, yte_iris, iris_labels = load_iris_dataset()
    # Load RFID dataset
    try:
        Xtr_rfid, Xte_rfid, ytr_rfid, yte_rfid, rfid_labels = load_rfid_dataset(rfid_path)
    except Exception as err:
        print(f"RFID data loading failed: {err}")
        return

    # Create the multi-class Adaline model with common parameters
    multi_adaline = MultiAdaline(
        eta=model_params['eta'],
        n_iter=model_params['n_iter'],
        random_state=model_params['random_state'],
        n_jobs=model_params['n_jobs']
    )

    print("\n" + "=" * 50)
    print("Evaluating MultiAdaline on Iris dataset")
    print("=" * 50)
    iris_metrics = evaluateClassifier(multi_adaline, Xtr_iris, Xte_iris, ytr_iris, yte_iris, iris_labels)

    print("\n" + "=" * 50)
    print("Evaluating MultiAdaline on RFID dataset")
    print("=" * 50)
    rfid_metrics = evaluateClassifier(multi_adaline, Xtr_rfid, Xte_rfid, ytr_rfid, yte_rfid, rfid_labels)

    # Compare training time and test accuracy
    iris_time = iris_metrics['train_time']
    rfid_time = rfid_metrics['train_time']
    iris_acc = iris_metrics['test_accuracy']
    rfid_acc = rfid_metrics['test_accuracy']
    time_ratio = rfid_time / iris_time if iris_time > 0 else float('inf')
    acc_diff = rfid_acc - iris_acc

    print("\n" + "=" * 50)
    print("Performance Comparison: Iris vs RFID")
    print("=" * 50)
    print(f"Iris training time: {iris_time:.4f} seconds")
    print(f"RFID training time: {rfid_time:.4f} seconds")
    print(f"RFID/Iris time ratio: {time_ratio:.2f} times")
    print(f"Iris test accuracy: {iris_acc:.4f}")
    print(f"RFID test accuracy: {rfid_acc:.4f}")
    print(f"Accuracy difference (RFID - Iris): {acc_diff:.4f}")

    # Visualization: Bar charts for training time and test accuracy
    fig, axs = plt.subplots(1, 2, figsize=(12, 5))
    axs[0].bar(["Iris", "RFID"], [iris_time, rfid_time], color=["skyblue", "salmon"])
    axs[0].set_title("Training Time Comparison")
    axs[0].set_ylabel("Time (seconds)")
    axs[1].bar(["Iris", "RFID"], [iris_acc, rfid_acc], color=["lightgreen", "tomato"])
    axs[1].set_title("Test Accuracy Comparison")
    axs[1].set_ylabel("Accuracy")
    plt.tight_layout()
    plt.show()


# ------------------------- Main Function -------------------------
def main():
    rfid_file = "all_w10_s1.arff"
    comparePerformance(rfid_file)


if __name__ == "__main__":
    main()
