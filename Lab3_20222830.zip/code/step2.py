import numpy as np
import matplotlib.pyplot as plt
from numpy.random import seed
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score


# ----- Binary AdalineSGD Implementation -----
class AdalineSGD(object):
    """ADAptive LInear NEuron classifier using Stochastic Gradient Descent.

    Parameters
    ------------
    eta : float
        Learning rate (between 0.0 and 1.0).
    n_iter : int
        Number of passes over the training dataset.
    shuffle : bool (default: True)
        Shuffles training data every epoch if True to prevent cycles.
    random_state : int (default: None)
        Set random state for shuffling and initializing the weights.
    """

    def __init__(self, eta=0.01, n_iter=10, shuffle=True, random_state=None):
        self.eta = eta
        self.n_iter = n_iter
        self.w_initialized = False
        self.shuffle = shuffle
        if random_state:
            seed(random_state)

    def fit(self, X, y):
        """Fit training data."""
        self._initialize_weights(X.shape[1])
        self.cost_ = []
        for i in range(self.n_iter):
            if self.shuffle:
                X, y = self._shuffle(X, y)
            cost = []
            for xi, target in zip(X, y):
                cost.append(self._update_weights(xi, target))
            err = sum(cost)
            self.cost_.append(err)
        return self

    def partial_fit(self, X, y):
        """Fit training data without reinitializing the weights."""
        if not self.w_initialized:
            self._initialize_weights(X.shape[1])
        if y.ravel().shape[0] > 1:
            for xi, target in zip(X, y):
                self._update_weights(xi, target)
        else:
            self._update_weights(X, y)
        return self

    def _shuffle(self, X, y):
        """Shuffle training data."""
        r = np.random.permutation(len(y))
        return X[r], y[r]

    def _initialize_weights(self, m):
        """Initialize weights to zeros."""
        self.w_ = np.zeros(1 + m)
        self.w_initialized = True

    def _update_weights(self, xi, target):
        """Apply Adaline learning rule to update the weights."""
        output = self.net_input(xi)
        error = (target - output)
        self.w_[1:] += self.eta * xi.dot(error)
        self.w_[0] += self.eta * error
        cost = 0.5 * error ** 2
        return cost

    def net_input(self, X):
        """Calculate net input."""
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def activation(self, X):
        """Compute linear activation (identity function)."""
        return self.net_input(X)

    def predict(self, X):
        """Return class label after unit step."""
        return np.where(self.activation(X) >= 0.0, 1, -1)


# ----- Multi-Class Adaline using One-vs-All Strategy -----
class MultiClassAdalineSGD(object):
    """
    Multi-class Adaline classifier using the One-vs-All (OvA) strategy.

    For each unique class, a binary AdalineSGD classifier is trained to distinguish
    that class (positive) from all other classes (negative). During prediction, the
    class corresponding to the classifier with the highest activation value is chosen.
    """

    def __init__(self, eta=0.01, n_iter=10, shuffle=True, random_state=None):
        self.eta = eta
        self.n_iter = n_iter
        self.shuffle = shuffle
        self.random_state = random_state
        self.classes_ = None
        self.models_ = {}  # Dictionary to store one binary classifier per class

    def fit(self, X, y):
        """Fit the multi-class model using the One-vs-All strategy."""
        self.classes_ = np.unique(y)
        self.models_ = {}
        for cls in self.classes_:
            # Create binary labels: +1 for the current class, -1 for all others
            y_binary = np.where(y == cls, 1, -1)
            model = AdalineSGD(eta=self.eta, n_iter=self.n_iter,
                               shuffle=self.shuffle, random_state=self.random_state)
            model.fit(X, y_binary)
            self.models_[cls] = model
        return self

    def net_input(self, X):
        """Compute activation values for each class.

        Returns:
            A matrix of shape (n_samples, n_classes) where each column corresponds
            to the activation values from one binary classifier.
        """
        activations = []
        for cls in self.classes_:
            model = self.models_[cls]
            activation = model.activation(X)
            activations.append(activation)
        return np.column_stack(activations)

    def predict(self, X):
        """Predict class labels based on activation values.

        For each sample, the predicted class is the one whose classifier yields
        the highest activation value.
        """
        activations = self.net_input(X)
        max_indices = np.argmax(activations, axis=1)
        return self.classes_[max_indices]

    def predict_activations(self, X):
        """Return activation values for each class."""
        return self.net_input(X)


# ----- Testing MultiClassAdalineSGD on the Iris Dataset -----
def test_multiclass_adaline():
    # Load the Iris dataset
    iris = load_iris()
    X = iris.data  # All 4 features
    y = iris.target  # Classes: 0, 1, 2

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    # Standardize features
    scaler = StandardScaler()
    X_train_std = scaler.fit_transform(X_train)
    X_test_std = scaler.transform(X_test)

    # Create and train the multi-class Adaline model
    multi_adaline = MultiClassAdalineSGD(eta=0.01, n_iter=15, shuffle=True, random_state=42)
    multi_adaline.fit(X_train_std, y_train)

    # Predict on the test set and compute accuracy
    y_pred = multi_adaline.predict(X_test_std)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Multi-class AdalineSGD accuracy on Iris dataset: {accuracy:.4f}")

    # Optionally, print activation values for the first 5 test samples
    activations = multi_adaline.predict_activations(X_test_std)
    print("Activation values for the first 5 test samples (columns correspond to classes):")
    print(activations[:5])

    return multi_adaline


if __name__ == "__main__":
    test_multiclass_adaline()
