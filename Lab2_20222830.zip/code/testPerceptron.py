import Perceptron as p  # 导入修改后的 Perceptron 类
import pandas as pd
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import numpy as np

# 加载数据集
df = pd.read_csv('all_w10_s1.csv')

# Step 1: Decode byte strings in the 'class' column
df['class'] = df['class'].apply(lambda x: x.decode('utf-8') if isinstance(x, bytes) else x)
df['class'] = df['class'].str.replace("b'", "").str.replace("'", "")

# Step 2: Filter only the two classes 'Chambre_a1' and 'Chambre_a2' for binary classification
df = df[df['class'].isin(['Chambre_a1', 'Chambre_a2'])]

# Check if any data is left after filtering
if df.empty:
    raise ValueError("No data left after filtering for 'Chambre_a1' and 'Chambre_a2'")

# Label encoding: 'Chambre_a1' -> 1, 'Chambre_a2' -> -1
y = df['class'].values
y = np.where(y == 'Chambre_a1', 1, -1)  # Convert classes to 1 and -1

# Step 3: Extract feature columns (excluding 'class' column)
X = df.drop(columns=['class']).values

# Step 4: Split data into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize the features (optional but recommended for Perceptron)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 5: Define and train the Perceptron model
ppn = p.Perceptron(eta=0.001, n_iter=10)
ppn.fit(X_train, y_train)

# Step 6: Output Confidence Intervals
confidence_scores = ppn.confidence(X_train)  # Confidence based on decision function
lower_bound = confidence_scores - 0.1  # Example margin for confidence interval
upper_bound = confidence_scores + 0.1

# Print confidence intervals with each pair on a new line for better readability
print("Confidence scores:")
for i in range(len(confidence_scores)):
    print(f"Sample {i+1}: Confidence = {confidence_scores[i]:.4f}, Interval: ({lower_bound[i]:.4f}, {upper_bound[i]:.4f})")

# Step 7: Evaluate the model on the test set
y_pred = ppn.predict(X_test)  # Get predictions from the Perceptron model
accuracy = np.mean(y_pred == y_test)  # Calculate accuracy manually
print(f"Accuracy on test set: {accuracy:.4f}")
