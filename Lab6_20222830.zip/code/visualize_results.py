import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.font_manager import FontProperties

# Experimental results data
results_data = {
    "Model": ["Majority Voting Classifier", "Random Forest Classifier", "Basic Stacking Classifier",
              "Multi-layer Stacking Model"],
    "Accuracy": [1.0, 1.0, 0.933, 0.933],
    "Precision": [1.0, 1.0, 0.945, 0.945],
    "Recall": [1.0, 1.0, 0.933, 0.933],
    "F1 Score": [1.0, 1.0, 0.933, 0.933]
}


def plot_performance_comparison():
    """Plot performance comparison of different models"""
    df = pd.DataFrame(results_data)

    # Set plot style
    plt.style.use('seaborn-v0_8')  # Updated to new style name
    plt.figure(figsize=(12, 6))

    # Create bar plot
    x = np.arange(len(df["Model"]))
    width = 0.2

    plt.bar(x - width * 1.5, df["Accuracy"], width, label="Accuracy", color='#2ecc71')
    plt.bar(x - width / 2, df["Precision"], width, label="Precision", color='#3498db')
    plt.bar(x + width / 2, df["Recall"], width, label="Recall", color='#e74c3c')
    plt.bar(x + width * 1.5, df["F1 Score"], width, label="F1 Score", color='#f1c40f')

    # Set plot properties
    plt.xlabel("Model", fontproperties=font)
    plt.ylabel("Score", fontproperties=font)
    plt.title("Performance Comparison of Different Ensemble Learning Models", fontproperties=font)
    plt.xticks(x, df["Model"], rotation=15, fontproperties=font)
    plt.legend(prop=font)
    plt.grid(True, linestyle='--', alpha=0.7)

    # Save plot
    plt.tight_layout()
    plt.savefig("model_performance_comparison.png", dpi=300, bbox_inches='tight')
    plt.close()


def plot_heatmap():
    """Plot heatmap of performance metrics"""
    df = pd.DataFrame(results_data)
    df_heatmap = df.set_index("Model")

    plt.figure(figsize=(10, 6))
    sns.heatmap(df_heatmap, annot=True, cmap='YlOrRd', fmt='.3f')
    plt.title("Heatmap of Ensemble Learning Model Performance Metrics", fontproperties=font)
    plt.xlabel("Evaluation Metric", fontproperties=font)
    plt.ylabel("Model", fontproperties=font)

    # Set tick label font
    plt.xticks(fontproperties=font)
    plt.yticks(fontproperties=font)

    # Save plot
    plt.tight_layout()
    plt.savefig("performance_heatmap.png", dpi=300, bbox_inches='tight')
    plt.close()


if __name__ == "__main__":
    # Generate visualization results
    plot_performance_comparison()
    plot_heatmap()
    print("Visualization results saved as 'model_performance_comparison.png' and 'performance_heatmap.png'")