import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

def plot_performance_metrics():
    """
    Create a bar plot comparing different metrics across models
    """
    # Read results
    df = pd.read_csv('wine_stacking_results.csv')
    
    # Set style
    plt.style.use('seaborn')
    plt.figure(figsize=(12, 6))
    
    # Create grouped bar plot
    metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
    x = range(len(df['Model']))
    width = 0.2
    
    for i, metric in enumerate(metrics):
        plt.bar([xi + width*i for xi in x], df[metric], width, 
                label=metric, alpha=0.8)
    
    # Customize plot
    plt.xlabel('Model Architecture')
    plt.ylabel('Score')
    plt.title('Performance Metrics Comparison Across Different Layer Configurations')
    plt.xticks([xi + width*1.5 for xi in x], df['Model'], rotation=15)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # Save plot
    plt.tight_layout()
    plt.savefig('wine_performance_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()

def plot_regression_metrics():
    """
    Create a line plot for regression metrics (MSE and R2)
    """
    # Read results
    df = pd.read_csv('wine_stacking_results.csv')
    
    # Create figure with two y-axes
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax2 = ax1.twinx()
    
    # Plot MSE
    color = 'tab:red'
    ax1.set_xlabel('Number of Layers')
    ax1.set_ylabel('Mean Squared Error', color=color)
    line1 = ax1.plot(df['Model'].str.extract('(\d+)').astype(int), 
                     df['MSE'], color=color, marker='o', 
                     label='MSE')
    ax1.tick_params(axis='y', labelcolor=color)
    
    # Plot R2 Score
    color = 'tab:blue'
    ax2.set_ylabel('R² Score', color=color)
    line2 = ax2.plot(df['Model'].str.extract('(\d+)').astype(int), 
                     df['R2 Score'], color=color, marker='s', 
                     label='R² Score')
    ax2.tick_params(axis='y', labelcolor=color)
    
    # Combine legends
    lines = line1 + line2
    labels = [l.get_label() for l in lines]
    plt.legend(lines, labels, loc='center right')
    
    # Customize plot
    plt.title('Regression Metrics vs Number of Layers')
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # Save plot
    plt.tight_layout()
    plt.savefig('wine_regression_metrics.png', dpi=300, bbox_inches='tight')
    plt.close()

def plot_heatmap():
    """
    Create a heatmap of all metrics
    """
    # Read results
    df = pd.read_csv('wine_stacking_results.csv')
    df_heatmap = df.set_index('Model')
    
    # Create heatmap
    plt.figure(figsize=(10, 6))
    sns.heatmap(df_heatmap, annot=True, cmap='YlOrRd', fmt='.3f')
    plt.title('Performance Metrics Heatmap')
    plt.xlabel('Metrics')
    plt.ylabel('Model Architecture')
    
    # Save plot
    plt.tight_layout()
    plt.savefig('wine_metrics_heatmap.png', dpi=300, bbox_inches='tight')
    plt.close()

if __name__ == "__main__":
    # Generate all visualizations
    plot_performance_metrics()
    plot_regression_metrics()
    plot_heatmap()
    print("Visualization results saved as PNG files.") 