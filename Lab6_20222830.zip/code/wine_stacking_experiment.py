import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')

class MultiLayerStacking:
    """
    Multi-layer stacking model implementation
    - Supports arbitrary number of layers
    - Uses perceptron as base classifier
    - Implements feature transfer between layers
    - Uses weighted average for final prediction
    """
    def __init__(self, n_layers=4):
        self.n_layers = n_layers
        self.models = []
        self.weights = None
        
    def fit(self, X, y):
        current_features = X.copy()
        
        # Train a perceptron for each layer
        for i in range(self.n_layers):
            layer_model = Perceptron(random_state=42)
            layer_model.fit(current_features, y)
            self.models.append(layer_model)
            
            # Get predictions from current layer as input features for next layer
            layer_predictions = layer_model.predict(current_features)
            current_features = np.column_stack((current_features, layer_predictions))
        
        # Calculate weights for each layer (equal weights initially)
        self.weights = np.ones(self.n_layers) / self.n_layers
        
    def predict(self, X):
        current_features = X.copy()
        all_predictions = []
        
        # Get predictions from each layer
        for model in self.models:
            layer_predictions = model.predict(current_features)
            all_predictions.append(layer_predictions)
            current_features = np.column_stack((current_features, layer_predictions))
        
        # Use weighted average for final predictions
        final_predictions = np.zeros_like(all_predictions[0], dtype=float)
        for i, pred in enumerate(all_predictions):
            final_predictions += pred.astype(float) * self.weights[i]
            
        return np.rint(final_predictions).astype(int)

def load_and_preprocess_data():
    """
    Load and preprocess the wine quality dataset
    """
    # Read data with semicolon separator
    data = pd.read_csv('winequality-white.csv', sep=';')
    
    # Split features and target
    X = data.drop('quality', axis=1)
    y = data['quality']
    
    # Split data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_test_scaled, y_train, y_test

def evaluate_model(y_true, y_pred, model_name):
    """
    Evaluate model performance using multiple metrics
    """
    results = {
        "Model": model_name,
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(y_true, y_pred, average='weighted'),
        "Recall": recall_score(y_true, y_pred, average='weighted'),
        "F1 Score": f1_score(y_true, y_pred, average='weighted'),
        "MSE": mean_squared_error(y_true, y_pred),
        "R2 Score": r2_score(y_true, y_pred)
    }
    return results

def main():
    """
    Main function to run the experiment
    """
    print("Loading and preprocessing data...")
    X_train, X_test, y_train, y_test = load_and_preprocess_data()
    
    # Test different numbers of layers
    n_layers_list = [2, 3, 4, 5]
    results = []
    
    print("\nTraining and evaluating models...")
    for n_layers in n_layers_list:
        print(f"\nTesting {n_layers}-layer stacking model...")
        model = MultiLayerStacking(n_layers=n_layers)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        results.append(evaluate_model(y_test, y_pred, f"{n_layers}-Layer Stacking"))
    
    # Convert results to DataFrame and save
    results_df = pd.DataFrame(results)
    results_df.to_csv('wine_stacking_results.csv', index=False)
    print("\nResults saved to 'wine_stacking_results.csv'")
    
    return results_df

if __name__ == "__main__":
    main() 