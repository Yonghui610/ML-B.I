import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.ensemble import StackingClassifier
import warnings

warnings.filterwarnings('ignore')

"""
Step 1: Test basic ensemble methods
- Use the Iris dataset and preprocess it
- Implement three basic ensemble methods: majority voting, random forest, and basic stacking
"""


def load_and_preprocess_data():
    """
    Step 1.1: Data loading and preprocessing
    - Load the Iris dataset
    - Separate features and labels
    - Split into training and test sets
    - Standardize features using StandardScaler
    - Convert string labels to numerical values using LabelEncoder
    """
    # Load data
    data = pd.read_csv('iris.csv', index_col=0)  # The first column is the index, not a feature

    # Separate features and labels
    X = data.drop('Species', axis=1)  # Use the correct label column name
    y = data['Species']

    # Convert string labels to numerical values
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Standardize features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return X_train_scaled, X_test_scaled, y_train, y_test, label_encoder


def implement_voting_classifier(X_train, X_test, y_train, y_test):
    """
    Step 1.2: Implement majority voting classifier
    - Create three random forest classifiers with different parameters as base classifiers
    - Combine predictions using hard voting
    - Evaluate classifier performance
    """
    # Create base classifiers
    clf1 = RandomForestClassifier(n_estimators=50, random_state=42)
    clf2 = RandomForestClassifier(n_estimators=100, random_state=42)
    clf3 = RandomForestClassifier(n_estimators=150, random_state=42)

    # Create voting classifier
    voting_clf = VotingClassifier(
        estimators=[('rf1', clf1), ('rf2', clf2), ('rf3', clf3)],
        voting='hard'
    )

    # Train and predict
    voting_clf.fit(X_train, y_train)
    y_pred = voting_clf.predict(X_test)

    return evaluate_model(y_test, y_pred, "Majority Voting Classifier")


def implement_random_forest(X_train, X_test, y_train, y_test):
    """
    Step 1.3: Implement random forest classifier
    - Build a random forest with 100 decision trees
    - Train the model and make predictions
    - Evaluate classifier performance
    """
    rf_clf = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_clf.fit(X_train, y_train)
    y_pred = rf_clf.predict(X_test)

    return evaluate_model(y_test, y_pred, "Random Forest Classifier")


def implement_basic_stacking(X_train, X_test, y_train, y_test):
    """
    Step 1.4: Implement basic stacking classifier
    - Use two random forests as base classifiers
    - Use one random forest as the meta-classifier
    - Implement two-layer stacking using StackingClassifier
    """
    estimators = [
        ('rf1', RandomForestClassifier(n_estimators=50, random_state=42)),
        ('rf2', RandomForestClassifier(n_estimators=100, random_state=42))
    ]

    stacking_clf = StackingClassifier(
        estimators=estimators,
        final_estimator=RandomForestClassifier(n_estimators=50, random_state=42)
    )

    stacking_clf.fit(X_train, y_train)
    y_pred = stacking_clf.predict(X_test)

    return evaluate_model(y_test, y_pred, "Basic Stacking Classifier")


"""
Step 2: Extend stacking to multiple layers
- Implement a custom multi-layer stacking model
- Use perceptrons as base classifiers
- Implement a four-layer stacking structure
- Combine predictions using weighted averaging
"""


class MultiLayerStacking:
    """
    Step 2.1: Implement custom multi-layer stacking model
    - Supports stacking with any number of layers
    - Uses perceptrons as base classifiers for each layer
    - Implements feature passing between layers
    - Uses weighted averaging for final predictions
    """

    def __init__(self, n_layers=4):
        self.n_layers = n_layers
        self.models = []
        self.weights = None

    def fit(self, X, y):
        """
        Step 2.2: Model training process
        - Train perceptrons layer by layer
        - Use predictions from each layer as input features for the next layer
        - Initialize weights for each layer
        """
        current_features = X.copy()

        # Train a perceptron for each layer
        for i in range(self.n_layers):
            layer_model = Perceptron(random_state=42)
            layer_model.fit(current_features, y)
            self.models.append(layer_model)

            # Get predictions from the current layer as input features for the next layer
            layer_predictions = layer_model.predict(current_features)
            current_features = np.column_stack((current_features, layer_predictions))

        # Calculate weights for each layer (based on validation set performance)
        self.weights = np.ones(self.n_layers) / self.n_layers

    def predict(self, X):
        """
        Step 2.3: Model prediction process
        - Get predictions from each layer
        - Combine predictions using weighted averaging
        - Return the final classification results
        """
        current_features = X.copy()
        all_predictions = []

        # Get predictions from each layer
        for model in self.models:
            layer_predictions = model.predict(current_features)
            all_predictions.append(layer_predictions)
            current_features = np.column_stack((current_features, layer_predictions))

        # Use weighted averaging for final predictions
        final_predictions = np.zeros_like(all_predictions[0], dtype=float)  # Use float type
        for i, pred in enumerate(all_predictions):
            final_predictions += pred.astype(float) * self.weights[i]  # Ensure float computation

        # Round the weighted average results and convert to integer type
        return np.rint(final_predictions).astype(int)


def implement_multilayer_stacking(X_train, X_test, y_train, y_test):
    """
    Step 2.4: Evaluate multi-layer stacking model
    - Create a 4-layer stacking model
    - Train the model and make predictions
    - Evaluate model performance
    """
    multi_stack = MultiLayerStacking(n_layers=4)
    multi_stack.fit(X_train, y_train)
    y_pred = multi_stack.predict(X_test)

    return evaluate_model(y_test, y_pred, "Multi-layer Stacking Model")


def evaluate_model(y_true, y_pred, model_name):
    """
    Step 4: Evaluate and compare performance
    - Calculate multiple evaluation metrics: accuracy, precision, recall, F1 score
    - Return a dictionary of evaluation results
    """
    results = {
        "Model": model_name,
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(y_true, y_pred, average='weighted'),
        "Recall": recall_score(y_true, y_pred, average='weighted'),
        "F1 Score": f1_score(y_true, y_pred, average='weighted')
    }
    return results


def main():
    """
    Main function: Execute experiments step by step and display results
    """
    # Step 1: Data preprocessing
    print("Step 1: Loading and preprocessing data...")
    X_train, X_test, y_train, y_test, label_encoder = load_and_preprocess_data()

    # Execute all experiments
    print("\nStarting experiments...")
    results = []

    # Step 1: Test basic ensemble methods
    print("Step 1: Testing basic ensemble methods...")
    results.append(implement_voting_classifier(X_train, X_test, y_train, y_test))
    results.append(implement_random_forest(X_train, X_test, y_train, y_test))
    results.append(implement_basic_stacking(X_train, X_test, y_train, y_test))

    # Step 2: Test multi-layer stacking
    print("Step 2: Testing multi-layer stacking model...")
    results.append(implement_multilayer_stacking(X_train, X_test, y_train, y_test))

    # Step 4: Display performance evaluation results
    print("\nStep 4: Experimental results evaluation:")
    results_df = pd.DataFrame(results)
    print(results_df.to_string(index=False))

    # Step 3: Analyze the connection to deep learning
    print("\nStep 3: Analysis of the connection to deep learning:")
    print(
        "1. Multi-layer structure: Stacking models extract features progressively through multiple layers, similar to hierarchical feature learning in deep learning")
    print(
        "2. Feature transformation: Each layer transforms the input, similar to non-linear transformations in deep learning")
    print(
        "3. Ensemble effect: The combination of multiple models provides an effect similar to multiple neurons in deep learning")

    print("\nAdvantages and disadvantages of stacking methods:")
    print("Advantages:")
    print("- Can automatically learn the optimal model combination")
    print("- Capable of handling complex non-linear relationships")
    print("- Has good generalization ability")
    print("\nDisadvantages:")
    print("- Higher computational cost")
    print("- Potential risk of overfitting")
    print("- Poor model interpretability")


if __name__ == "__main__":
    main()